void ESC_init();

void stop();

void move(int motor, int speed, int direction);

void moveState(int state);
