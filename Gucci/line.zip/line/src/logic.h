//
// Created by Logan Schick on 9/6/2018.
//

#ifndef SUMO_HOTFUZZ_H
#define SUMO_HOTFUZZ_H

void fuzzy_init();

void getToF();

void doFuzzy();

void checkSwitch();

void checkLine();

void checkEncoders();

#endif //SUMO_HOTFUZZ_H
